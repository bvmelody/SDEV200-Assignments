import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int evenSum, oddSum, digits;
        boolean validCard;

        System.out.print("Enter a credit card number as a long integer: ");
        long number = input.nextLong();
        validCard = isValid(number);

        if (validCard == true) {
            System.out.printf("%d is valid", number);
        }
        else {
            System.out.printf("%d is invalid", number);
        }

        /**if (digits >= 13 && digits <= 16){
            evenSum = sumOfDoubleEvenPlace(number);
            oddSum = sumOfOddPlace(number);
            int combinedSum = evenSum + oddSum;
            System.out.print(combinedSum);
            int divisibleCheck = combinedSum % 10;
            if (divisibleCheck == 0){
                System.out.printf("%d is valid", number);
            }
            else {
                System.out.printf("%d is invalid", number);
            }
        }
        else {
            System.out.printf("%d is invalid", number);
        }**/
    }

    public static boolean isValid(long number) {
        //System.out.print(sumOfDoubleEvenPlace(number));
        //System.out.print(sumOfOddPlace(number));
        int sum = sumOfDoubleEvenPlace(number) + sumOfOddPlace(number);
        if ((sum % 10 == 0) && (prefixMatched(number, 1) == true) && (getSize(number) >= 13) && (getSize(number) <= 16)){
            return true;
        }
        else{
            return false;
        }
    }

    public static int sumOfDoubleEvenPlace(long number){
        int sum = 0;
        number = number / 10;
        while (number != 0){
            int digit = (int) (number % 10);
            digit *= 2;
            digit = getDigit(digit);
            sum += digit;
            number = number / 100;
        }

        /**for (int index = getSize(number) - 1; index >= 0; index--){
            if((index % 2) == 0){
                long remainder = number % 10;
                int digit = (int) remainder;
                int digitAdjust = getDigit(digit);
                sum += digitAdjust;
                number = number / 10;
            }
            else{
                number = number / 10;
            }
        }*/

        //System.out.printf("%d\r\n", sum);
        return sum;
    }

    public static int sumOfOddPlace(long number){
        int sum = 0;
        while (number > 0){
            sum += (int) (number % 10);
            number = number / 100;
        }
        /**for (int index = getSize(number) - 1; index >= 0; index--){
            if((index % 2) >= 1){
                long remainder = number % 10;
                int digit = (int) remainder;
                sum += digit;
                number = number / 10;
            }
            else{
                number = number / 10;
            }
        }*/

        //System.out.print(sum);
        return sum;
    }

    public static int getDigit(int number){

        if (number > 9){
            int digit1 = number % 10;
            //System.out.printf("%d \r\n", digit1);
            int digit2 = (int) number / 10;
            //System.out.printf("%d \r\n", digit2);

            return digit1 + digit2;
        }
        else{
            return number;
        }
    }

    public static int getSize(long d){
        int count = 0;
        while (d > 0){
            d = d / 10;
            count++;
        }
        return count;
    }

    public static boolean prefixMatched(long number, int d){
        if ((getPrefix(number, d) == 4)) {
            return true;
        } else if ((getPrefix(number, d) == 5)) {
            return true;
        } else if ((getPrefix(number, d) == 6)) {
            return true;
        } else if ((getPrefix(number, d) == 37)) {
            return true;
        } else {
            return false;
        }
    }

    public static long getPrefix(long number, int k){

        if (getSize(number) < k){
            return number;
        }
        else{
            int length = getSize(number);
            for (int i = 0; i < (length - k); i++){
                number = number / 10;
            }
            return number;
        }
        /**for (int i = getSize(number); i > k; i--) {
            if (getSize(number) > k) {
                number = number / 10;
            } else {
                return number;
            }
        }
        return number;*/
    }

    /**public static boolean isValid(long number){
        while (number > 10){
            number = number / 10;
        }
        return number >= 3 && number <= 6;
    }*/



}