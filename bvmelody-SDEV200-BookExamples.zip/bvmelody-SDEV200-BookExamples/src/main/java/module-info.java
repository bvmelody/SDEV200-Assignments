module com.example.bvmelodysdev200bookexamples {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.bvmelodysdev200bookexamples to javafx.fxml;
    exports com.example.bvmelodysdev200bookexamples;
}