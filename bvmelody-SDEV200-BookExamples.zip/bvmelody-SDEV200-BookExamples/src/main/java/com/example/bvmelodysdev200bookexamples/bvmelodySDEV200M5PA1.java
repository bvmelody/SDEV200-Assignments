package com.example.bvmelodysdev200bookexamples;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.geometry.Insets;
import javafx.stage.Stage;

public class bvmelodySDEV200M5PA1 extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        GridPane grid = new GridPane();
        int flagCount = 1;
        Image flag1 = new Image(getClass().getResourceAsStream("ProjectImages/flag1.png"));
        Image flag2 = new Image(getClass().getResourceAsStream("ProjectImages/flag2.png"));
        Image flag3 = new Image(getClass().getResourceAsStream("ProjectImages/flag3.png"));
        Image flag4 = new Image(getClass().getResourceAsStream("ProjectImages/flag4.png"));

        ImageView flagView = new ImageView(flag1);
        flagView.setFitHeight(flag1.getHeight());
        flagView.setFitWidth(flag1.getWidth());
        ImageView flagView1 = new ImageView(flag2);
        flagView1.setFitHeight(flag2.getHeight());
        flagView1.setFitWidth(flag2.getWidth());
        ImageView flagView2 = new ImageView(flag3);
        flagView2.setFitHeight(flag3.getHeight());
        flagView2.setFitWidth(flag3.getWidth());
        ImageView flagView3 = new ImageView(flag4);
        flagView3.setFitHeight(flag3.getHeight());
        flagView3.setFitWidth(flag3.getWidth());

        grid.getChildren().addAll(flagView, flagView1, flagView2, flagView3);



        /*for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                //grid.add(new ImageView(new Image("res/ProjectImages/flag"+flagCount+".png")), i, j);
                //grid.add(new ImageView(getClass().getResourceAsStream("/ProjectImages/flag"+flagCount+".png").toString()), i, j);
                flagCount++;
            }
        }*/

        Scene scene = new Scene(grid, 3000, 3000);
        primaryStage.setTitle("Flags of the World of Kaiserreich");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void main(String[] args) {
        Application.launch(args);
    }

}
