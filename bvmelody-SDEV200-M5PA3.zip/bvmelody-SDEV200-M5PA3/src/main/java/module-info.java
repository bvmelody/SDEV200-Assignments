module com.example.bvmelodysdev200m5pa3 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.bvmelodysdev200m5pa3 to javafx.fxml;
    exports com.example.bvmelodysdev200m5pa3;
}