package com.example.bvmelodysdev200m5pa3;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.control.Slider;
import javafx.scene.text.Text;
import javafx.scene.control.Label;

public class SlideBarProgram extends Application {
    protected Text text = new Text("Slider Test");
    protected Slider sliderRed = new Slider();
    protected Slider sliderGreen = new Slider();
    protected Slider sliderBlue = new Slider();
    protected Slider sliderOpacity = new Slider();

    @Override
    public void start(Stage primaryStage) {
        StackPane pane = new StackPane(text);
        pane.setPadding(new Insets(30, 30, 30, 30));

        sliderRed.setMin(0);
        sliderRed.setMax(1.0);
        sliderGreen.setMin(0);
        sliderGreen.setMax(1.0);
        sliderBlue.setMin(0);
        sliderBlue.setMax(1.0);
        sliderOpacity.setMin(0);
        sliderOpacity.setMax(1.0);

        sliderRed.valueProperty().addListener(ov -> setColor());
        sliderGreen.valueProperty().addListener(ov -> setColor());
        sliderBlue.valueProperty().addListener(ov -> setColor());
        sliderOpacity.valueProperty().addListener(ov -> setColor());
        sliderOpacity.setValue(1);

        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.add(new Label("Red"), 0, 0);
        gridPane.add(sliderRed, 1, 0);
        gridPane.add(new Label("Green"), 0, 1);
        gridPane.add(sliderGreen, 1, 1);
        gridPane.add(new Label("Blue"), 0, 2);
        gridPane.add(sliderBlue, 1, 2);
        gridPane.add(new Label("Opacity"), 0, 3);
        gridPane.add(sliderOpacity, 1, 3);

        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(gridPane);
        borderPane.setBottom(pane);

        Scene scene = new Scene(borderPane, 300, 300);
        primaryStage.setTitle("Slider Test");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    private void setColor() {
        text.setFill(new Color(sliderRed.getValue(), sliderGreen.getValue(), sliderBlue.getValue(), sliderOpacity.getValue()));
    }
}
