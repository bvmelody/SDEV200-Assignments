/*import java.util.GregorianCalendar;
public class bvmelodySDEV200M2PA1 {
    public static void main(String[] args) {
        MyDate date1 = new MyDate();
        MyDate date2 = new MyDate(34355555133101L);

        // printing statements
        System.out.println("Current Date: ");
        System.out.println("Month: " + date1.getMonth());
        System.out.println("Day: " + date1.getDay());
        System.out.println("Year: " + date1.getYear());

        System.out.println("Date: " + date2);
    }
    private int month;
    private int day;
    private int year;
    public int getMonth() {
        return month;
    }
    public int getDay() {
        return day;
    }
    public int getYear() {
        return year;
    }
}*/