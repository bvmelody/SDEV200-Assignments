import java.util.Scanner;
import java.util.GregorianCalendar;

public class bvmelodySDEV200M2PA1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        MyDate date1 = new MyDate();
        MyDate date2 = new MyDate(34355555133101L);
        System.out.println("Input the amount of time in milliseconds: ");
        long dateInput = input.nextLong();
        MyDate date3 = new MyDate(dateInput);

        System.out.println("Current Date: ");
        System.out.printf("%d / %d / %d\r\n", date1.getMonth(), date1.getDay(), date1.getYear());
        System.out.printf("%d / %d / %d\r\n", date2.getMonth(), date2.getDay(), date2.getYear());
        System.out.printf("%d / %d / %d", date3.getMonth(), date3.getDay(), date3.getYear());
    }
    public static class MyDate{
        private int year;
        private int month;
        private int day;

        MyDate(long milliseconds){
            setYear(milliseconds);
            setMonth(milliseconds);
            setDay(milliseconds);
        }

        MyDate(){
            this(System.currentTimeMillis());
        }

        MyDate(int year, int month, int day){
            this.year = year;
            this.month = month;
            this.day = day;
        }
        int getYear(){
            return year;
        }
        int getMonth(){
            return month;
        }
        int getDay(){
            return day;
        }
        void setYear(long timeMilliseconds){
            GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTimeInMillis(timeMilliseconds);
            this.year = calendar.get(GregorianCalendar.YEAR);
        }
        void setMonth(long timeMilliseconds){
            GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTimeInMillis(timeMilliseconds);
            this.month = calendar.get(GregorianCalendar.MONTH);
        }
        void setDay(long timeMilliseconds){
            GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTimeInMillis(timeMilliseconds);
            this.day = calendar.get(GregorianCalendar.DAY_OF_MONTH);
        }
        void setDate(long elapsedMilliseconds){
            setYear(elapsedMilliseconds);
            setMonth(elapsedMilliseconds);
            setDay(elapsedMilliseconds);
        }
    }
}
