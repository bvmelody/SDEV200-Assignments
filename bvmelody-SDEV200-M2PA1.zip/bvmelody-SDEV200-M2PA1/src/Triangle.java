public class Triangle extends GeometricObject{

}
