package com.example.bvmelodysdev200m6pa1;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import java.util.Scanner;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.*;

public class StaffDatabaseApplication extends Application {
    private PreparedStatement statement1;
    private PreparedStatement statement2;
    private TextField lastName = new TextField();
    private TextField firstName = new TextField();
    private TextField middleInitial = new TextField();
    private TextField address = new TextField();
    private TextField phone = new TextField();
    private TextField idCode = new TextField();
    private TextField city = new TextField();
    private TextField state = new TextField();
    private TextArea displayText = new TextArea();
    private Label status = new Label();

    @Override
    public void start(Stage stage) throws IOException {
        initializeDB();
        BorderPane pane = new BorderPane();
        GridPane grid = new GridPane();
        Button viewButton = new Button("View");
        Button insertButton = new Button("Insert");
        Button updateButton = new Button("Update");
        Button clearButton = new Button("Clear");
        HBox hbox1 = new HBox();
        hbox1.getChildren().addAll(new Label("ID"), idCode);
        HBox hbox2 = new HBox();
        hbox2.getChildren().addAll(new Label("Last Name"), lastName,
                new Label("First Name"), firstName, new Label("MI"), middleInitial);
        HBox hbox3 = new HBox();
        hbox3.getChildren().addAll(new Label("Address"), address);
        HBox hbox4 = new HBox();
        hbox4.getChildren().addAll(new Label("City"), city, new Label("State"), state);
        HBox hbox5 = new HBox();
        hbox5.getChildren().addAll(new Label("Telephone"), phone);
        HBox hbox6 = new HBox();
        hbox6.getChildren().addAll(viewButton, insertButton, updateButton, clearButton);
        VBox vbox = new VBox();
        vbox.getChildren().addAll(hbox1, hbox2, hbox3, hbox4, hbox5, hbox6);
        pane.setTop(vbox);
        insertButton.setOnAction(event -> insertion());
        viewButton.setOnAction(event -> showTable());

        Scene scene = new Scene(pane);
        stage.setTitle("Staff Database Application");
        stage.setScene(scene);
        stage.show();


    }

    private void initializeDB(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Connecting to database...");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/staffDatabase", "root", "7hisIsMyPassword!");
            System.out.println("Connection Established!");
        } catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private void insertion(){
        String lastName = this.lastName.getText();
        String firstName = this.firstName.getText();
        String middleInitial = this.middleInitial.getText();
        String address = this.address.getText();
        String city = this.city.getText();
        String state = this.state.getText();
        String phone = this.phone.getText();
        String idCode = this.idCode.getText();

        try{
            statement1.setString(1, idCode);
            statement1.setString(2, firstName);
            statement1.setString(3, lastName);
            statement1.setString(4, middleInitial);
            statement1.setString(5, address);
            statement1.setString(6, city);
            statement1.setString(7, state);
            statement1.setString(8, phone);

            int rows = statement1.executeUpdate();
            if(rows > 0){
                System.out.println("Insertion Successful!");
            } else{
                System.out.println("Insertion Failed!");
            }
        } catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private void showTable(){
        String id = idCode.getText();
        try {
            statement2.setString(1, String.valueOf(idCode));
            ResultSet resultSet = statement2.executeQuery();

            if(resultSet.next()){
                String lastName = resultSet.getString(1);
                String firstName = resultSet.getString(2);
                String middleInitial = resultSet.getString(3);
                String address = resultSet.getString(4);
                String city = resultSet.getString(5);
                String state = resultSet.getString(6);
                String phone = resultSet.getString(7);

                displayText.appendText(firstName + " " + middleInitial + " " + lastName + "\n" + " Address: " + address + " " + city + " " + state + "\n" + "Phone Number: " + phone + "\n");
            } else {
                status.setText("Error: Data not found");
            }
        } catch (SQLException ex){
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch();
    }
}