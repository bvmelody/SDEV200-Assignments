import java.util.Scanner;

public class binaryConverter {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please input a binary number: ");
        System.out.println(bin2Dec(input.nextLine()));
    }

    public static int bin2Dec(String binary) throws FormatException {

        if (!isBinary(binary)) {
            throw new FormatException(binary + " is not a binary number.");
        }
        int power = 0;
        int decimal = 0;
        for (int i = binary.length() - 1; i >= 0; i--) {

            if (binary.charAt(i) == '1') {
                decimal += Math.pow(2, power);
            }
            power++;
        }
        return decimal;
    }

    public static boolean isBinary(String binary) {

        for (char ch : binary.toCharArray()) {
            if (ch != '1' && ch != '0') return false;
        }
        return true;
    }

}

class FormatException extends IllegalArgumentException {

    FormatException(String s) {
        super(s);
    }
}
