// Project name: bvmelody-SDEV200-M1PA1
// Author: Brenden Melody
// Date last updated: 8/24/2024
// Description: This program is designed to output a table of measurements in feet and meters and what they convert to


public class Main {
    public static void main(String[] args) {
        // initializing my variables
        double foot = 1.0;
        double meter = 20.0;
        double convertedFoot;
        double convertedMeter;

        // formatting the table header
        System.out.printf("%-8s %-10s | %8s %10s\r\n", "Feet", "Meters", "Meters", "Feet");
        for (int i = 0; i < 45; i++){
            System.out.printf("-");
        }

        // table body
        System.out.printf("\r\n"); // this creates a new line to separate the table header from the output table
        for (double i = 1.0; i < 11.0; i++){
            convertedFoot = meterToFoot(meter); // conversion from meter to foot
            convertedMeter = footToMeter(foot); // conversion from foot to meter
            System.out.printf("%-8.1f %-10.3f |   %-12.1f %-10.3f\r\n", foot, convertedMeter, meter, convertedFoot);
            foot = foot + 1;
            meter = meter + 5;
        }


    }

    // this converts feet to meters
    public static double footToMeter(double foot) {
        double meter;
        meter = foot * .305;
        return meter;
    }

    // this converts meters to feet
    public static double meterToFoot(double meter) {
        double foot;
        foot = meter * 3.279;
        return foot;
    }


}


