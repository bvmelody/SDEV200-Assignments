package GeometricObject;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter three sides of the Triangle");
        double side1 = input.nextDouble();
        double side2 = input.nextDouble();
        double side3 = input.nextDouble();

        Triangle triangle = new Triangle(side1, side2, side3);

        System.out.println("Enter the color of the Triangle");
         triangle.setColor(input.next());

        System.out.println(" Is the Triangle filled? Reply with 'True' or 'False' ");
        triangle.setFilled(input.nextBoolean());

        System.out.println("The Triangle Sides are \n side 1: " + triangle.getSide1() + "\n Side 2: " + triangle.getSide2() + "\n Side 3: " + triangle.getSide3());
        System.out.println("The Triangle's Area is " + triangle.getArea());
        System.out.println("The Triangle's Perimeter is "+ triangle.getPerimeter());
        System.out.println("The Triangle's Color is " + triangle.getColor());
        System.out.println("Is the Triangle filled? " + triangle.isFilled());

    }
}
/*public class Main {
    private double side1 = 1.0;
    private double side2 = 1.0;
    private double side3 = 1.0;

    public static void main(String[] args) {
        Triangle triangle1 = new Triangle(side1, side2, side3);


        Scanner input = new Scanner(System.in);

        System.out.println("Enter the side1: ");
        double side1 = input.nextDouble();
        System.out.println("Enter the side2: ");
        double side2 = input.nextDouble();
        System.out.println("Enter the side3: ");
        double side3 = input.nextDouble();

        System.out.println("Enter the color for the triangle: ");
        String color = input.next();
        System.out.println("Is the triangle filled in (True/False)?");
        String filled = input.next();

        System.out.println("The triangles sides are: \r\n");
        System.out.println("Side 1: " + triangle1.getSide1() + "\r\n");
        System.out.println("Side 2: " + triangle1.getSide2() + "\r\n");
        System.out.println("Side 3: " + triangle1.getSide3() + "\r\n");

        System.out.println("The triangle's are is: " + triangle1.getArea() + "\r\n");
        System.out.println("The triangle's color is: " + triangle1.getColor());
        System.out.println("The triangle's perimeter is: " + triangle1.getPerimeter() + "\r\n");
        System.out.println("Is the triangle filled? " + triangle1.isFilled() + "\r\n");
    }



}

 */
