package com.example.bvmelodysdev200finalproject;

import java.util.Scanner;

public class Player {
    String name;
    int turnNumber = 0;
    String color;
    String[] Colors = {"Red", "Blue", "Green", "Yellow", "Orange", "Violet", "PINK"};


    String chooseColor(){
        while(true) {
            Scanner scanner = new Scanner(System.in);
            for (String color : Colors) {
                System.out.println(color);
            }
            System.out.println("Choose the color for your game pieces: ");
            color = scanner.nextLine();
            if (color.equals("Red")) {
                return color;
            } else if (color.equals("Blue")) {
                return color;
            } else if (color.equals("Green")) {
                return color;
            } else if (color.equals("Yellow")) {
                return color;
            } else if (color.equals("Orange")) {
                return color;
            } else if (color.equals("Violet")) {
                return color;
            } else if (color.equals("PINK")) {
                return color;
            } else {
                System.out.println("Invalid color - try again");
            }
        }
    }
}
