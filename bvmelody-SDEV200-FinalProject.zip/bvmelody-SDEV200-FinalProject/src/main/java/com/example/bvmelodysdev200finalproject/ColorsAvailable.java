package com.example.bvmelodysdev200finalproject;

public class ColorsAvailable {
    String[] Colors = {"Red", "Blue", "Green", "Yellow", "Orange", "Violet", "PINK"};
}
