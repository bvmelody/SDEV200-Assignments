package com.example.bvmelodysdev200finalproject;


/* I'm thinking of maybe switching to instead of doing Connect 4 to just
doing tic-tac-toe considering how complex this is going to be as I was trying
to write the code for this way too late since I've been really busy this week.
But I'll try and go for one more week and see if I'm feeling better, if not I'll
send you a message. I'm also going to be completely redoing my UML and classes
since after this previous module I realized I could build this in a much better
way using javafx.
 */

public class Main {
    public static void main(String[] args) {
        Player player1 = new Player();
        Player player2 = new Player();

        player1.color = player1.chooseColor();
        player2.color = player2.chooseColor();
    }
}
