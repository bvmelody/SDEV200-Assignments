package com.example.bvmelodysdev200finalproject;

public class Grid {
    int COLUMNS = 7;
    int ROWS = 6;
    //int [6][7] fieldArray;
}
