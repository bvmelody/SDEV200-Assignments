package com.example.bvmelodysdev200finalproject;

import javafx.scene.shape.Circle;




public class gridCircle extends Grid {
    String color;
    int fieldPosX;
    int fieldPosY;

    /*setCircle(){

    }*/


}
