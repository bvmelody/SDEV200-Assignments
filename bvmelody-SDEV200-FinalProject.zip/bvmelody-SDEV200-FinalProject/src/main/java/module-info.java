module com.example.bvmelodysdev200finalproject {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.bvmelodysdev200finalproject to javafx.fxml;
    exports com.example.bvmelodysdev200finalproject;
}