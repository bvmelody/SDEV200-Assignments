package com.example.bvmelodysdev200m5pa22;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.shape.Circle;

public class CircleColorChange extends Application {
    @Override
    public void start(Stage primaryStage) {
        double width = 800;
        double height = 600;
        Circle circle = new Circle(width / 2, height / 2, Math.min(width, height) / 10, Color.WHITE);
        circle.setStroke(Color.BLACK);

        StackPane pane = new StackPane(circle);
        //pane.setOnMousePressed(event -> circle.setFill(Color.RED));
        //pane.setOnMouseReleased(event -> circle.setFill(Color.WHITE));

        primaryStage.setTitle("Circle ColorChange");
        primaryStage.setScene(new Scene(pane, width, height));
        pane.setOnMousePressed(event -> circle.setFill(Color.RED));
        pane.setOnMouseReleased(event -> circle.setFill(Color.WHITE));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
