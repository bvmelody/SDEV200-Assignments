module com.example.bvmelodysdev200m5pa22 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.bvmelodysdev200m5pa22 to javafx.fxml;
    exports com.example.bvmelodysdev200m5pa22;
}