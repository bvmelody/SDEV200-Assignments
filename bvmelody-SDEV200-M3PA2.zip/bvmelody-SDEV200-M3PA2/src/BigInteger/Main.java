

package BigInteger;

import java.math.BigInteger;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the first rational number: ");
        BigInteger a = input.nextBigInteger();
        BigInteger b = input.nextBigInteger();
        Rational ratNum1 = new Rational(a, b);
        System.out.print("Enter the second rational number: ");
        BigInteger c = input.nextBigInteger();
        BigInteger d = input.nextBigInteger();
        Rational ratNum2 = new Rational(c, d);

        System.out.println(ratNum1 + " + " + ratNum2 + " = " + ratNum1.add(ratNum2));
        System.out.println(ratNum1 + " - " + ratNum2 + " = " + ratNum1.subtract(ratNum2));
        System.out.println(ratNum1 + " * " + ratNum2 + " = " + ratNum1.multiply(ratNum2));
        System.out.println(ratNum1 + " / " + ratNum2 + " = " + ratNum1.divide(ratNum2));
        System.out.println(ratNum2 + " is " + ratNum2.doubleValue());

    }
}