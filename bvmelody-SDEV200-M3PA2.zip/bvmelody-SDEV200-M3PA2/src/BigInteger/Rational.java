package BigInteger;

import java.math.BigInteger;

public class Rational extends Number implements Comparable<Rational> {
    private BigInteger numerator = BigInteger.ZERO;
    private BigInteger denominator = BigInteger.ONE;
    //private long numerator = 0;
    //private long denominator = 1;

    public Rational(){
        this(new BigInteger("0"), new BigInteger("1"));
    }
    public Rational(BigInteger num1, BigInteger denom1) {
        BigInteger gcd = gcd(num1, denom1);
        numerator = (denom1.compareTo(BigInteger.ZERO) > 0 ? BigInteger.ONE :
                new BigInteger("-1")).multiply(num1.divide(gcd));
        denominator = denom1.divide(gcd);
    }

    private static BigInteger gcd(BigInteger n, BigInteger d){
        BigInteger num1 = n;
        BigInteger num2 = d;
        BigInteger gcd = BigInteger.ONE;

        for (BigInteger k = BigInteger.ONE;
             k.compareTo(num1) <= 0 && k.compareTo(num2) <= 0;
             k = k.add(BigInteger.ONE)) {
            if (num1.remainder(k).compareTo(BigInteger.ZERO) == 0 &&
                    num2.remainder(k).compareTo(BigInteger.ZERO) == 0){
                gcd = k;
            }
        }
        return gcd;
    }

    public BigInteger getNumerator() {
        return  numerator;
    }
    public BigInteger getDenominator() {
        return denominator;
    }

    public Rational add(Rational secondRational){
        BigInteger n = (numerator.multiply(secondRational.getDenominator())).add(
                denominator.multiply(secondRational.getNumerator()));
        BigInteger d = denominator.multiply(secondRational.getDenominator());
        return new Rational(n, d);
    }

    public Rational subtract(Rational secondRational){
        BigInteger n = (numerator.multiply(secondRational.getDenominator())).subtract(
                denominator.multiply(secondRational.getNumerator()));
        BigInteger d = denominator.multiply(secondRational.getDenominator());
        return new Rational(n, d);
    }

    public Rational multiply(Rational secondRational){
        BigInteger n = numerator.multiply(secondRational.getNumerator());
        BigInteger d = denominator.multiply(secondRational.getDenominator());
        return new Rational(n, d);
    }

    public Rational divide(Rational secondRational){
        BigInteger n = numerator.multiply(secondRational.getDenominator());
        BigInteger d = denominator.multiply(secondRational.getNumerator());
        return new Rational(n, d);
    }

    @Override
    public String toString() {
        if (denominator.compareTo(BigInteger.ONE) == 0){
            return numerator + "";
        }
        else{
            return numerator + "/" + denominator;
        }
    }

    @Override
    public boolean equals(Object other){
        if ((this.subtract((Rational)(other))).getNumerator().compareTo(BigInteger.ZERO) == 0){
            return true;
        }
        else{
            return false;
        }
    }

    @Override
    public int intValue() {
        return (int)doubleValue();
    }

    @Override
    public float floatValue() {
        return (float)doubleValue();
    }

    @Override
    public double doubleValue() {
        return this.getNumerator().doubleValue() / this.getDenominator().doubleValue();
    }

    @Override
    public long longValue() {
        return (long)doubleValue();
    }

    @Override
    public int compareTo(Rational o){
        BigInteger num = this.subtract((Rational)o).getNumerator();
        if (this.subtract((Rational)o).getNumerator().compareTo(BigInteger.ZERO) > 0){
            return 1;
        }
        else if (this.subtract((Rational)o).getNumerator().compareTo(BigInteger.ZERO) < 0){
            return -1;
        }
        else{
            return 0;
        }
    }
}
