package GeometricObject;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to GeometricObject");
        System.out.println("Please enter the shape you would like to create: ");
        String shapeName = input.nextLine();

        if (shapeName.equals("Rectangle") || shapeName.equals("rectangle")) {
            System.out.println("Sorry this is unavailable at the moment.");
        } else if (shapeName.equals("Circle") || shapeName.equals("circle")) {
            Circle[] circles = new Circle[2];
            circleFunction(circles);
            int count = 0;
            circleCompare(circles);

        }
        else if (shapeName.equals("Triangle") || shapeName.equals("triangle")) {
            Triangle[] triangles = new Triangle[5];
            triangleFunction(triangles);
            int count = 0;
        }


    }

    public static void circleFunction(Circle[] circles) {
        //Circle[] circles = new Circle[5];
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < circles.length; i++){
            System.out.println("Please enter the radius of the circle: ");
            double radius = input.nextDouble();
            circles[i] = new Circle(radius);
            System.out.println("Enter the color of the circle: ");
            circles[i].setColor(input.next());
            System.out.println("Is the circle filled? Please reply with 'True' or 'False' ");
            circles[i].setFilled(input.nextBoolean());

            System.out.println("The radius of the circle is: " + circles[i].getRadius());
            System.out.println("The area of the circle is: " + circles[i].getArea());
            System.out.println("The perimeter of the circle is: " + circles[i].getPerimeter());
            System.out.println("The color of the circle is: " + circles[i].getColor());
            System.out.println("Is the circle filled? " + circles[i].isFilled());


            System.out.println("Would you like to make another circle? Reply with 'yes' or 'no' ");
            if (input.next().equals("yes")){
            }
            else if (input.next().equals("no")){
                break;
            }
        }
    }

    public static void triangleFunction(Triangle[] triangles) {
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < triangles.length; i++){
            System.out.println("Please enter the three sids of the triangle: ");
            double side1 = input.nextDouble();
            double side2 = input.nextDouble();
            double side3 = input.nextDouble();
            triangles[i] = new Triangle(side1, side2, side3);
            System.out.println("Enter the color of the triangle: ");
            triangles[i].setColor(input.next());
            System.out.println("Is the triangle filled? Please reply with 'True' or 'False' ");
            triangles[i].setFilled(input.nextBoolean());
            System.out.println("The Triangle's Area is " + triangles[i].getArea());
            System.out.println("The Triangle's Perimeter is " + triangles[i].getPerimeter());
            System.out.println("The Triangle's Color is " + triangles[i].getColor());
            System.out.println("Is the Triangle filled? " + triangles[i].isFilled());
        }
    }


    public static void circleCompare(Circle[] circles) {
        boolean compare = false;
        if(circles[0].compareTo(circles[1]) == 0){
            compare = true;
        } else if (circles[0].compareTo(circles[1]) > 0) {
            compare = false;
        } else if (circles[0].compareTo(circles[1]) < 0) {
            compare = false;
        }
        if (compare == true) {
            System.out.println("Circle 1 and Circle 2 are the same");
        } else{
            System.out.println("Circle 1 and Circle 2 are not the same");
        }
    }
}
