package bvmelodySDEV200M4PA3;

public class Node<E> {
    E element;
    Node<E> next;
    Node<E> prev;

    public Node(E element){
        this.element = element;
    }
}
