package bvmelodySDEV200M4PA3;

import java.util.ListIterator;

public class TwoWayLinkedList<E> implements MyList<E> {
    private Node<E> head, tail;
    private int size = 0;

// default pathway
    public TwoWayLinkedList() {

    }

    public TwoWayLinkedList(E[] objects) {
        for (E e: objects) {
            addLast(e);
        }
    }

    // returning first element if wanted
    public E getFirst(){
        if (size == 0){
            return null;
        }
        else{
            return head.element;
        }
    }

    // returning last element if wanted
    public E getLast(){
        if (size == 0){
            return null;
        }
        else{
            return tail.element;
        }
    }
// modified for accepting both the next and previous values
    public void addFirst(E e){
        Node<E> newNode = new Node<>(e);
        newNode.next = head;
        if (head != null){
            head.prev = newNode;
        }
        head = newNode;
        if (tail == null){
            tail = newNode;
        }
        size++;
    }

    public void addLast(E e){
        Node<E> newNode = new Node<>(e);

        if (tail != null){
            tail.next = newNode;
            newNode.prev = tail;
        }
        tail = newNode;
        if (head == null){
            head = newNode;
        }
        size++;
    }

    public void add(int index, E e){
        if (index == 0) addFirst(e);
        else if (index >= size) addLast(e);
        else{
            Node<E> current = head;
            for (int i = 0; i < index; i++) {
                current = current.next;
            }
            Node<E> tempNode = new Node<>(e);
            tempNode.next = current.next;
            tempNode.prev = current;
            if (current.next != null){
                current.next.prev = tempNode;
            }
            current.next = tempNode;
            size++;
        }
    }

    public E removeFirst(){
        if (size == 0) return null;
        else{
            Node<E> temp = head;
            head = head.next;
            size--;
            if (head == null) tail = null;
            return temp.element;
        }
    }
    public E removeLast(){
        if (size == 0 || size == 1) return removeFirst();
        else{
            Node<E> current = head;
            for (int i = 0; i < size-2; i++) {
                current = current.next;
            }

            E temp = tail.element;
            tail = current;
            tail.next = null;
            size--;
            return temp;
        }
    }

    @Override
    public E remove(int index){
        if (index < 0 || index >= size) return null;
        else if (index == 0) return removeFirst();
        else if (index == size - 1) return removeLast();
        else{
            Node<E> previous = head;

            for (int i = 0; i < index; i++) {
                previous = previous.next;
            }

            Node<E> current = previous.next;
            previous.next = current.next;
            size--;
            return current.element;
        }
    }

    @Override /** Override toString() to return elements in the list */
    public String toString() {
        StringBuilder result = new StringBuilder();

        Node<E> current = head;
        for (int i = 0; i < size; i++) {
            result.append(current.element);
            current = current.next;
            if (current != null) result.append(", ");
            else {
                result.append("]");
            }
        }
        return result.toString();
    }

    @Override /** Clear the list */
    public void clear(){
        size = 0;
        head = tail = null;
    }

    @Override /** Return true if this list contains the element e */
    public boolean contains(Object e){
        return true;
    }

    @Override /** Return the element at the specified index */
    public E get(int index){
        return null;
    }

    @Override /** Return the index of the first matching element in this list Return -1 if no match. */
    public int indexOf(Object e){
        return 0;
    }

    @Override /** Return the index of the last matching element in this list. Return -1 if no match. */
    public int lastIndexOf(E e){
        return 0;
    }

    @Override /** Replace the element at the specified position in this list with the specified element. */
    public E set(int index, E e){
        return null;
    }

    @Override /** Override iterator() defined Iterable */
    public java.util.Iterator<E> iterator(){
        return new LinkedListIterator();
    }

    /** This took me way to long to figure out. For some reason my brain was interpreting the book instructions
     * as it wanting us to create our own versions of the Iterator and ListIterator methods, not realizing they were
     * incorporated into java itself. I think I'm losing it.
     */
    private class LinkedListIterator implements java.util.Iterator<E>, java.util.ListIterator<E> {
        private Node<E> current = head;
        private int index = 0;

        public boolean hasNext() {
            return current != null;
        }

        public E next() {
            E e = current.element;
            current = current.next;
            index++;
            return e;
        }

        public boolean hasPrevious() {
            return current != null && current.prev != null;
        }

        @Override
        public E previous() {
            current = current.prev;
            index--;
            return current.element;
        }

        @Override
        public int nextIndex() {
            return 0;
        }

        @Override
        public int previousIndex() {
            return 0;
        }

        /**public E prev(){
            current = current.prev;
            index--;
            return current.element;
        }*/

        @Override
        public void remove() {}

        @Override
        public void set(E e) {

        }

        @Override
        public void add(E e) {

        }
    }

    public class Node<E>{
        E element;
        Node<E> next;
        Node<E> prev;
        public Node(E e){
            element = e;
        }
    }

    @Override /** Return the number of elements in this list. */
    public int size(){
        return size;
    }
}
