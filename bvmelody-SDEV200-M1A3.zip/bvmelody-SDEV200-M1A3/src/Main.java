import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int[][] matrix1 = new int[3][3];
        int[][] matrix2 = new int[3][3];

        //matrix1 = new int[3][3];

        System.out.print("Enter list1: ");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                matrix1[i][j] = input.nextInt();
            }
        }

        System.out.print("Enter list2: ");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                matrix2[i][j] = input.nextInt();
            }
        }

        boolean same = equals(matrix1, matrix2);
        if (same) {
            System.out.println("The two arrays are identical");
        }
        else {
            System.out.println("The two arrays are not identical");
        }
    }

    public static boolean equals(int[][] m1, int[][] m2) {
        boolean same = true;
        //int indexInt = m1[0][0];
        for (int i = 0; i < m2.length; i++) {
            /**if (m1[0][i] != m2[0][i]) {
                while ()
                for (int j = 0; j < m2.length; j++) {

                }
            }*/
            for (int j = 0; j < m2[i].length; j++) {
                if (equalConfirm(m1[i][j], m2)) {
                    same = true;
                }
                else {
                    same = false;
                }
            }
        }
        return same;
    }

    public static boolean equalConfirm(int index, int[][] m2){
        boolean same = false;
        for (int i = 0; i < m2.length; i++) {
            for (int j = 0; j < m2[i].length; j++) {
                if (m2[i][j] == index){
                    same = true;
                }
            }
        }
        return same;
    }

}