package com.example.bvmelodyfinalproject;

import javafx.scene.paint.Color;

public class Player {
    private String playerName;
    private Color color;
    public Player(String playerName, Color color) {
        this.playerName = playerName;
        this.color = color;
    }
    public String getPlayerName() {
        return playerName;
    }
    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }
    public Color getColor() {
        return color;
    }
    public void setColor(Color color) {
        this.color = color;
    }
}
