package com.example.bvmelodyfinalproject;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;

/*
I realize now that this project was way beyond my abilities and that I wasn't prepared for how tough this would be going
into it. I'm sorry I couldn't get this whole thing completed, it was a struggle to get it into this state with another
class and a job. I hope to retake this again in the next semester or the semester after if I am unable to pass the course.
 */

public class MainMenu extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        BorderPane pane = new BorderPane();
        Player player1 = new Player("Player 1", Color.AQUA);
        Player player2 = new Player("Player 2", Color.RED);
        pane.setPrefSize(250, 100);
        Scene scene = new Scene(pane);
        Label label = new Label("Welcome to Connect 4!");
        HBox hbox1 = new HBox(label);
        Button startButton = new Button("Start Game");
        HBox hbox2 = new HBox(startButton);
        Button registerButton = new Button("Register Players");
        HBox hbox3 = new HBox(registerButton);
        Button exitButton = new Button("Exit");
        HBox hbox4 = new HBox(exitButton);
        VBox vbox1 = new VBox();
        VBox vbox2 = new VBox();
        vbox1.getChildren().add(hbox1);
        vbox2.getChildren().addAll(hbox2, hbox3, hbox4);
        pane.setTop(vbox1);
        pane.setCenter(vbox2);
        stage.setTitle("Game Menu");
        stage.setScene(scene);
        stage.show();


        startButton.setOnAction(e -> {
            Stage stage2 = new Stage();
            BorderPane pane2 = new BorderPane();
            Scene scene2 = new Scene(pane2);
            GameBoard gameBoard = new GameBoard(6, 7);
            gameBoard.createBoard();
            stage2.setScene(scene2);
            stage2.show();

        });
        registerButton.setOnAction(e -> {Player_Registry.main(player1, player2);});



        exitButton.setOnAction(e -> {System.exit(0);});
    }

    public static void main(String[] args) {
        launch();
    }
}