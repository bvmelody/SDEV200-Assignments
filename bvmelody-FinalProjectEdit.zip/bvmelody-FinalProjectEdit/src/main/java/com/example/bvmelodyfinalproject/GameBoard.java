package com.example.bvmelodyfinalproject;

import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;

import java.util.ArrayList;
import java.util.List;

public class GameBoard {
    private static final int PIECE_DIAMETER = 40;
    private int playerX = 0;
    private int playerY = 0;
    private int rows;
    private int columns;
    private int board[][];
    private int movesMade;
    private Move lastMove;

    public GameBoard(int rows, int columns) {
        this.rows = rows;
        this.columns = columns;
        this.board = new int[rows][columns];
        this.movesMade = 0;
        this.lastMove = new Move(0, 0);
    }

    public void createBoard(){
        GridPane grid = new GridPane();
        grid.setPrefSize(1000, 1000);
        for (int row = 0; row < rows; row++){
            for (int column = 0; column < columns; column++){
                Rectangle tile = new Rectangle(50, 50);
                tile.setFill(Color.WHITE);
                tile.setStroke(Color.BLACK);

                grid.add(tile, column, row);
                GridPane.setRowIndex(tile, row);
                GridPane.setColumnIndex(tile, column);

                tile.setOnMouseClicked(e -> {});
            }
        }
    }

    private List<Rectangle> interactiveColumns(){
        List<Rectangle> interactiveColumns = new ArrayList<>();
        for (int column = 0; column < columns; column++){
            Rectangle rectangle = new Rectangle(PIECE_DIAMETER, (rows)*PIECE_DIAMETER);
            rectangle.setFill(Color.WHITE);
            rectangle.setTranslateX(column * columns);

            rectangle.setOnMouseEntered(e -> rectangle.setFill(Color.BLACK));
        }
        return interactiveColumns;
    }

    public int[][] getGameBoard() {
        return board;
    }

    public int getMovesMade() {
        return movesMade;
    }

    public Move getLastMove() {
        return lastMove;
    }

    public void makeMove(Move move, int player) {
        board[move.getCol()][move.getRow()] = player;
    }

    public int checkWinConditions(int row, int column, int player) {
        if (column >= columns - 4) {
            if (board[row][column] == player && board[row][column - 1] == player
            && board[row][column - 2] == player && board[row][column - 3] == player) {
                return player;
            }
        }

        if (column <= columns - 4) {
            if (board[row][column] == player && board[row][column + 1] == player
            && board[row][column + 2] == player && board[row][column + 3] == player) {
                return player;
            }
        }

        if (row >= rows - 4) {
            if (board[row][column] == player && board[row - 1][column] == player
            && board[row - 2][column] == player && board[row - 3][column] == player) {
                return player;
            }
        }

        if (row <= rows - 4) {
            if (board[row][column] == player && board[row + 1][column] == player
            && board[row + 2][column] == player && board[row + 3][column] == player) {
                return player;
            }
        }

        if (column >= columns - 4 && row >= rows - 3) {
            if (board[row][column] == player && board[row - 1][column - 1] == player
            && board[row - 2][column - 2] == player && board[row - 3][column - 3] == player) {
                return player;
            }
        }

        if (column <= columns - 4 && row <= rows - 4) {
            if (board[row][column] == player && board[row + 1][column + 1] == player
                    && board[row + 2][column + 2] == player && board[row + 3][column + 3] == player) {
                return player;
            }
        }

        if (column <= columns - 4 && row >= rows - 3) {
            if (board[row][column] == player && board[row - 1][column + 1] == player
                    && board[row - 2][column + 2] == player && board[row - 3][column + 3] == player) {
                return player;
            }
        }

        if (column >= columns - 4 && row <= rows - 4) {
            if (board[row][column] == player && board[row + 1][column - 1] == player
                    && board[row + 2][column - 2] == player && board[row + 3][column - 3] == player) {
                return player;
            }
        }

        return 0;
    }

    public int checkWinStatus(Move move, int board[][]) {
        int x = checkWinConditions(move.getRow(), move.getCol(), playerX);
        int y = checkWinConditions(move.getRow(), move.getCol(), playerY);

        if(x == playerX){
            return x;
        }
        if(y == playerY){
            return y;
        }

        if(movesMade == rows * columns){
            return 0;
        }

        return 1;
    }

}
