package com.example.bvmelodyfinalproject;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Player_Registry {
    public static void main(Player player1, Player player2) {
        // this is the player registry and allows the players to change their names
        System.out.println("Player_Registry called");
        BorderPane pane = new BorderPane();
        Scene scene = new Scene(pane);
        Stage window = new Stage();
        Label label = new Label("Please enter the player names: ");
        HBox hbox = new HBox(label);
        TextArea player1Name = new TextArea("Player 1");
        HBox hbox1 = new HBox(player1Name);
        TextArea player2Name = new TextArea("Player 2");
        HBox hbox2 = new HBox(player2Name);
        Button confirmNames = new Button("Confirm Names");
        HBox hbox3 = new HBox(confirmNames);
        VBox vbox = new VBox(hbox, hbox1, hbox2, hbox3);
        pane.setTop(vbox);

        // This actually changes the player names. sadly I can't let them change colors for the moment
        confirmNames.setOnAction(e -> {
            player1.setPlayerName(player1Name.getText());
            player2.setPlayerName(player2Name.getText());
            window.close();
        });
        window.setTitle("Player Registry");
        window.setScene(scene);
        window.show();
    }
}
