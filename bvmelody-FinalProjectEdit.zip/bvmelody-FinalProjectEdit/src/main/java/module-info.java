module com.example.bvmelodyfinalproject {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.bvmelodyfinalproject to javafx.fxml;
    exports com.example.bvmelodyfinalproject;
}