package ComparisonFile;

import java.io.*;
import java.util.*;

public class ReadFile {
    public static void main(String[] args) throws IOException {
        Scanner fileInput = new Scanner(System.in);
        System.out.println("Enter the file name: ");
        String fileName = fileInput.nextLine();
        File file = new File(fileName);
        if (args.length != 1) {
            System.out.println("Usage: java SourceCodeFileName");
            System.exit(1);
        }


        if (!file.exists()) {
            System.out.println("File not found: " + file.getAbsolutePath());
            System.exit(1);
        }

        Stack<Character> groupingSymbols = new Stack<>();

        try (Scanner input = new Scanner(file)) {
            while (input.hasNextLine()) {
                String line = input.nextLine();
                for (int i = 0; i < line.length(); i++) {
                    char character = line.charAt(i);
                    if (character == '(' || character == '{' || character == '[') {
                        groupingSymbols.push(character);
                    }
                    else if (character == ')' || character == '}' || character == ']') {
                        if (groupingSymbols.peek() == '(' && character == ')' || groupingSymbols.peek() == '{' && character == '}' || groupingSymbols.peek() == '[' && character == ']') {
                            groupingSymbols.pop();
                        }
                        else if ((groupingSymbols.peek() != '(' && character == ')') ||
                                groupingSymbols.peek() != '{' && character == '}' ||
                                groupingSymbols.peek() != '[' && character == ']') {
                            System.out.println("This program doesn't have the corresponding closing brackets for the amount of opening brackets.");
                            System.exit(1);
                        }
                    }
                }
            }
        }

        System.out.println("This source code " + (groupingSymbols.isEmpty() ? "has " : "doesn't have ") + "the corresponding closing pairs.");

    }
}