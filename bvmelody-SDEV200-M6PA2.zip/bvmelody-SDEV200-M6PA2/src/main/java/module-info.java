module com.example.bvmelodysdev200m6pa2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.java;


    opens com.example.bvmelodysdev200m6pa2 to javafx.fxml;
    exports com.example.bvmelodysdev200m6pa2;
}