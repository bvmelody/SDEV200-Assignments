package com.example.bvmelodysdev200m6pa2;

import com.mysql.cj.Query;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import java.sql.*;
import javafx.stage.Stage;

import java.io.IOException;

public class DbBatchUpdate extends Application {
    Connection connection;


    @Override
    public void start(Stage stage) throws IOException {

    }

    public void displayPane(){
        connection = null;
        Label connectionLabel = new Label("Connecting to the database");
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.add(new Label("JDBC Drive: "), 0, 0);
        TextField jdbcDriver = new TextField();
        gridPane.add(jdbcDriver, 1, 0);

        gridPane.add(new Label("Database URL: "), 0, 1);
        TextField dbURL = new TextField();
        gridPane.add(dbURL, 1, 1);
        gridPane.add(new Label("Username: "), 0, 2);
        TextField user = new TextField();
        gridPane.add(user, 1, 2);
        gridPane.add(new Label("Password: "), 0, 3);
        TextField password = new TextField();
        gridPane.add(password, 1, 3);

        Button connectButton = new Button("Connect to Database");
        BorderPane.setAlignment(connectButton, Pos.TOP_RIGHT);

        connectButton.setOnAction(e -> {
            try{
                Class.forName(jdbcDriver.getText().trim());
                String url = dbURL.getText().trim();
                String username = user.getText().trim();
                String passWord = password.getText().trim();

                connection = DriverManager.getConnection(url, username, passWord);
                connectionLabel.setText("Connected to the database");
                displayPane();
            }catch (Exception ex){
                connectionLabel.setText(ex.getMessage());
            }
        });
    }

    private void test(){
        Label connectionLabel = new Label("");
        Button connectButton = new Button("Connect to Database");
        HBox hBox = new HBox(10, connectionLabel, connectButton);

        TextArea secondArea = new TextArea();

        Button batchUpdateButton = new Button("Batch Update");
        Button nonBatchUpdateButton = new Button("Non-Batch Update");
        HBox batchUpdateButtonHBox = new HBox(10, batchUpdateButton, nonBatchUpdateButton);

        connectButton.setOnAction(e -> displayPane());

        batchUpdateButton.setOnAction(e -> {
            connectionLabel.setText("");
            long startTime = System.currentTimeMillis();
            try{
                Statement statement = connection.createStatement();
                for (int i = 0; i < 1_000; i++)
                {
                    String query = Query.replace("!", Math.random() + "");
                    query = query.replace("@", Math.random() + "");
                    query = query.replace("#", Math.random() + "");
                    statement.addBatch(query);
                }
                statement.executeBatch();
            } catch(Exception ex){
                {
                    ex.printStackTrace();
                }
                long end = System.currentTimeMillis();
                connectionLabel.setText("Batch Update succeeded");
                secondArea.appendText("Batch update completed\n");
                secondArea.appendText("The elapsed Time is " + (end - startTime) + "\n\n");
            }
        });

        nonBatchUpdateButton.setOnAction(e ->
        {
            connectionLabel.setText("");
            long start = System.currentTimeMillis();
            for (int i = 0; i < 1_000; i++)
            {
                try
                {
                    Statement statement = connection.createStatement();
                    String query = Query.class.("!", Math.random() + "");
                    query = query.replace("@", Math.random() + "");
                    query = query.replace("#", Math.random() + "");
                    statement.executeUpdate(query);
                }
                catch (Exception exception)
                {
                    exception.printStackTrace();
                }
            }
            long end = System.currentTimeMillis();
            connectionLabel.setText("Non-Batch Update succeeded");
            secondArea.appendText("Non-Batch update completed\n");
            secondArea.appendText("The elapsed Time is " + (end - start) + "\n\n");
        });
    }

    public static void main(String[] args) {
        launch();
    }
}